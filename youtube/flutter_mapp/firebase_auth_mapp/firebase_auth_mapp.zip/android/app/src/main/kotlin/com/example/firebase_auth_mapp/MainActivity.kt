package com.example.firebase_auth_mapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
