package com.example.firestore_quickstart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
